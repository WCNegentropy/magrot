"""
Stability analysis module — available in MagRot Pro.

The Hessian eigenvalue solver, entropy audit framework, constraint
manifold mapping, and basin-of-attraction characterization are part
of the MagRot Pro commercial product.
"""
raise ImportError(
    "magrot.stability is not included in magrot-core. "
    "The stability analysis suite is available in MagRot Pro."
)
