"""Tests for the thermodynamics module (Phase 2A / 2C)."""

import numpy as np
import pytest
from scipy.constants import mu_0

from magrot.fields.grid import CylindricalGrid
from magrot.fields.analytic import field_zpinch_bennett, field_theta_pinch
from magrot.rotation.metrics import compute_all_metrics
from magrot.thermodynamics.free_energy import (
    magnetic_energy_density,
    thermal_energy_density,
    total_energy_density,
    free_energy_cylindrical,
    lyapunov_R_cylindrical,
    local_free_energy_gradient,
)
from magrot.thermodynamics.entropy import (
    spitzer_resistivity,
    constant_resistivity,
    temperature_from_pressure,
    temperature_profile_parabolic,
    entropy_production_resistive,
    total_entropy_production_cylindrical,
    dissipated_power,
)
from magrot.thermodynamics.constraints import (
    vector_potential_cylindrical,
    magnetic_helicity_cylindrical,
    total_poloidal_flux_cylindrical,
    total_mass_cylindrical,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def zpinch_setup():
    """Standard Z-pinch Bennett equilibrium for testing."""
    I = 1e4
    a = 0.01
    grid = CylindricalGrid(Nr=200, Ntheta=1, Nz=1, r_range=(0.0003, 0.05))
    B, p = field_zpinch_bennett(grid, I=I, a=a)
    return B, p, grid, I, a


@pytest.fixture
def theta_pinch_setup():
    """Standard theta-pinch for testing."""
    grid = CylindricalGrid(Nr=200, Ntheta=1, Nz=1, r_range=(0.0003, 0.05))
    B, p = field_theta_pinch(grid, B0=1.0, a=0.01, beta=0.5)
    return B, p, grid


# ── Free energy tests ─────────────────────────────────────────────────────────

class TestFreeEnergy:
    def test_magnetic_energy_density_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        u_B = magnetic_energy_density(B)
        assert np.all(u_B >= 0)
        assert np.any(u_B > 0)

    def test_thermal_energy_density_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        u_th = thermal_energy_density(p)
        assert np.all(u_th >= 0)

    def test_total_energy_is_sum(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        u_total = total_energy_density(B, p)
        u_B = magnetic_energy_density(B)
        u_th = thermal_energy_density(p)
        np.testing.assert_allclose(u_total, u_B + u_th, rtol=1e-12)

    def test_free_energy_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        F, u = free_energy_cylindrical(B, grid, p)
        assert F > 0

    def test_free_energy_zero_pressure_only_magnetic(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        F_with, _ = free_energy_cylindrical(B, grid, p)
        F_without, _ = free_energy_cylindrical(B, grid)
        # With pressure should be larger
        assert F_with > F_without

    def test_lyapunov_R_equilibrium_small(self, zpinch_setup):
        """At Bennett equilibrium, |R-1|^2 integrated should be relatively small."""
        B, p, grid, _, a = zpinch_setup
        res = compute_all_metrics(B, grid, p_mat=p)
        R_u = res['R_universal']
        L, dev = lyapunov_R_cylindrical(R_u, grid)
        # L should be finite and non-negative
        assert L >= 0
        assert np.isfinite(L)

    def test_lyapunov_R_perturbed_larger(self, zpinch_setup):
        """Perturbed state should have larger Lyapunov than equilibrium."""
        B, p, grid, _, _ = zpinch_setup
        res_eq = compute_all_metrics(B, grid, p_mat=p)
        L_eq, _ = lyapunov_R_cylindrical(res_eq['R_universal'], grid)

        # Perturb pressure by 50%
        p_pert = p * 1.5
        res_pert = compute_all_metrics(B, grid, p_mat=p_pert)
        L_pert, _ = lyapunov_R_cylindrical(res_pert['R_universal'], grid)

        assert L_pert > L_eq


# ── Entropy production tests ─────────────────────────────────────────────────

class TestEntropy:
    def test_spitzer_resistivity_decreases_with_T(self):
        T = np.array([1e6, 1e7, 1e8])
        eta = spitzer_resistivity(T)
        assert eta[0] > eta[1] > eta[2]

    def test_constant_resistivity_uniform(self):
        T = np.array([1e6, 1e7, 1e8])
        eta = constant_resistivity(T, eta_value=1e-5)
        np.testing.assert_allclose(eta, 1e-5)

    def test_temperature_from_pressure(self):
        from scipy.constants import k as k_B
        p = 1e5  # Pa
        n = 1e20  # m^-3
        T = temperature_from_pressure(p, n)
        expected = p / (2 * n * k_B)
        np.testing.assert_allclose(T, expected, rtol=1e-10)

    def test_entropy_production_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        from magrot.stress.maxwell import compute_forces_conservative_cyl
        phys = compute_forces_conservative_cyl(B, grid, p)
        J = phys['J']
        T = np.full_like(phys['Bmag'], 1e7)

        s_dot, Jmag2, eta = entropy_production_resistive(J, T)
        assert np.all(s_dot >= 0)
        assert np.any(s_dot > 0)  # J != 0 inside plasma

    def test_total_entropy_production_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        from magrot.stress.maxwell import compute_forces_conservative_cyl
        phys = compute_forces_conservative_cyl(B, grid, p)
        J = phys['J']
        T = np.full_like(phys['Bmag'], 1e7)

        s_dot, _, _ = entropy_production_resistive(J, T)
        S_dot = total_entropy_production_cylindrical(s_dot, grid)
        assert S_dot > 0

    def test_dissipated_power_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        from magrot.stress.maxwell import compute_forces_conservative_cyl
        phys = compute_forces_conservative_cyl(B, grid, p)
        J = phys['J']
        T = np.full_like(phys['Bmag'], 1e7)

        s_dot, _, _ = entropy_production_resistive(J, T)
        P = dissipated_power(s_dot, T, grid=grid)
        assert P > 0


# ── Constraint tests ──────────────────────────────────────────────────────────

class TestConstraints:
    def test_vector_potential_shape(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        A = vector_potential_cylindrical(B, grid)
        assert A.shape == B.shape

    def test_magnetic_helicity_finite(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        K = magnetic_helicity_cylindrical(B, grid)
        assert np.isfinite(K)

    def test_total_mass_positive(self, zpinch_setup):
        B, p, grid, _, _ = zpinch_setup
        rho = np.ones(grid.R.shape) * 1e-6  # uniform density
        M = total_mass_cylindrical(rho, grid)
        assert M > 0
