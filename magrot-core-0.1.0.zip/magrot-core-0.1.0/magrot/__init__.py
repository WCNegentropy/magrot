"""
MagRot Core: Rotational-Vector Framework for Magnetic Field Dynamics
====================================================================

A dimensionless rotational parameter R(x) that encodes the local tendency
toward collapse, expansion, or equilibrium in magnetic field configurations.

Metrics:
    R_kappa     -- Metric A: curvature ratio (kappa / kappa_eq)
    R_collapse  -- Metric B: collapse indicator (1 + C)
    R_misalign  -- Metric C: current-field misalignment |B x curl(B)| / |B|^2
    R_universal -- Universal: |f_inward| / |f_outward|

Convention (force-ratio):
    R < 1  ->  Expanding (outward forces dominate)
    R = 1  ->  Equilibrium (force balance)
    R > 1  ->  Contracting (inward forces dominate)

Thermodynamics:
    free_energy      -- F[B, p] functional computation
    entropy          -- Local entropy production rate s_dot(x)
    constraints      -- Helicity K, flux Phi, mass M conservation

Author: WCNEGENTROPY HOLDINGS LLC
License: MIT
"""

__version__ = "0.1.0"
