"""
State flow engine — available in MagRot Pro.

The entropy-parameterized variational relaxation solver is part of the
MagRot Pro commercial product.
"""
raise ImportError(
    "magrot.thermodynamics.state_flow is not included in magrot-core. "
    "The state flow engine is available in MagRot Pro."
)
