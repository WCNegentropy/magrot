"""
Thermodynamic diagnostic module.

Provides free energy computation, entropy production analysis, and
conservation constraint evaluation for magnetic field configurations.

Submodules
----------
free_energy   -- F[B, p] functional computation
entropy       -- Local entropy production rate density s_dot(x)
constraints   -- Magnetic helicity K, total flux Phi, total mass M
"""
