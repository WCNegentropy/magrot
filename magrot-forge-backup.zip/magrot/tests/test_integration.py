"""
End-to-end integration tests for MagRot Forge.

Tests the full pipeline: init coils -> optimize -> verify -> export.
Also includes memory profiling and performance benchmarking.

Run:  JAX_ENABLE_X64=True python -m pytest tests/test_integration.py -v
"""

import jax
jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np
import pytest
import json
import os
import tempfile
import time

from magrot.jax_core.magrot_generative import ForgeConfig, run_forge, load_checkpoint
from magrot.jax_core.grid_jax import make_grid_info
from magrot.jax_core.biot_savart import (
    init_circular_coils, fourier_to_all_coils,
    grid_to_eval_points, biot_savart_field,
    cartesian_to_cylindrical_B,
)
from magrot.jax_core.forge_loss import forge_loss, forge_loss_scalar
from magrot.jax_core.metrics_jax import compute_R_universal_jax
from magrot.jax_core.tournament import (
    init_tournament_candidates, evaluate_batch,
    tournament_select, optimize_candidate,
)


class TestEndToEnd:
    """Full pipeline integration tests."""

    def test_init_to_optimize_to_checkpoint(self):
        """Init coils -> optimize 50 steps -> verify loss decreased -> load checkpoint."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = ForgeConfig(
                Nr=8, Ntheta=4, Nz=4,
                N_coils=2, N_fourier=3, N_segments=16,
                N_steps=50, learning_rate=5e-3,
                log_every=10, checkpoint_every=25,
                output_dir=tmpdir, seed=123,
            )
            results = run_forge(config)

            # Loss should decrease at some point during training
            # (with cosine decay on tiny grids, final may not be lowest)
            min_loss = min(results['history']['loss'])
            assert min_loss < results['history']['loss'][0], \
                "Loss never decreased during optimization"

            # Checkpoints should exist
            assert os.path.exists(os.path.join(tmpdir, 'coil_params_step25.npy'))
            assert os.path.exists(os.path.join(tmpdir, 'coil_params_step50.npy'))
            assert os.path.exists(os.path.join(tmpdir, 'history.json'))

            # Load checkpoint should work
            params, history, step = load_checkpoint(tmpdir)
            assert step == 50
            assert params.shape == (2, 3, 3, 2)

    def test_coil_visualization_data(self):
        """Verify coil points can be generated for visualization."""
        params = init_circular_coils(N_coils=3, N_fourier=5)
        pts = fourier_to_all_coils(params, N_segments=64)
        assert pts.shape == (3, 64, 3)
        assert jnp.all(jnp.isfinite(pts))

    def test_r_field_computation(self):
        """Verify R_universal can be computed from Biot-Savart output."""
        grid_info = make_grid_info(Nr=10, Ntheta=8, Nz=5,
                                    r_range=(0.3, 1.2), z_range=(-0.3, 0.3))
        eval_cart = grid_to_eval_points(grid_info)
        params = init_circular_coils(N_coils=3, N_fourier=5,
                                      major_radius=0.7, minor_radius=0.4)
        coil_pts = fourier_to_all_coils(params, 32)
        B_cart = biot_savart_field(coil_pts, eval_cart)
        B_cyl = cartesian_to_cylindrical_B(B_cart, eval_cart)
        B_grid = B_cyl.reshape(10, 8, 5, 3)
        R_field, phys = compute_R_universal_jax(B_grid, grid_info)

        assert R_field.shape == (10, 8, 5)
        assert jnp.all(jnp.isfinite(R_field))
        assert float(jnp.min(R_field)) >= 0.01  # R_MIN
        assert float(jnp.max(R_field)) <= 100.0  # R_MAX


class TestTournament:
    """Tests for tournament infrastructure."""

    def test_init_candidates(self):
        """Verify candidate initialization produces valid params."""
        config = {'N_coils': 2, 'N_fourier': 3}
        all_params = init_tournament_candidates(4, config, seed=77)
        assert all_params.shape == (4, 2, 3, 3, 2)
        assert jnp.all(jnp.isfinite(all_params))

    def test_evaluate_batch(self):
        """Verify batch evaluation returns valid losses."""
        config = {'N_coils': 2, 'N_fourier': 3}
        all_params = init_tournament_candidates(3, config, seed=88)
        grid_info = make_grid_info(Nr=8, Ntheta=4, Nz=4,
                                    r_range=(0.3, 1.2), z_range=(-0.3, 0.3))
        eval_cart = grid_to_eval_points(grid_info)

        losses, aux = evaluate_batch(all_params, grid_info, eval_cart,
                                      N_segments=16)

        assert losses.shape == (3,)
        assert jnp.all(jnp.isfinite(losses))
        assert jnp.all(losses > 0)
        assert 'L_R' in aux
        assert 'R_mean' in aux

    def test_tournament_select(self):
        """Verify selection keeps the right candidates."""
        config = {'N_coils': 2, 'N_fourier': 3}
        all_params = init_tournament_candidates(8, config, seed=99)
        grid_info = make_grid_info(Nr=8, Ntheta=4, Nz=4,
                                    r_range=(0.3, 1.2), z_range=(-0.3, 0.3))
        eval_cart = grid_to_eval_points(grid_info)

        losses, aux = evaluate_batch(all_params, grid_info, eval_cart,
                                      N_segments=16)

        survivors, indices, surv_losses = tournament_select(
            all_params, losses, aux, survival_rate=0.5)

        # Should keep at least 50% (4 of 8) + any Pareto-optimal extras
        assert survivors.shape[0] >= 4
        # Survivors should include the best-by-loss candidate
        best_idx = int(jnp.argmin(losses))
        assert best_idx in indices

    def test_optimize_single_candidate(self):
        """Verify single-candidate optimization reduces loss."""
        grid_info = make_grid_info(Nr=8, Ntheta=4, Nz=4,
                                    r_range=(0.3, 1.2), z_range=(-0.3, 0.3))
        eval_cart = grid_to_eval_points(grid_info)
        params = init_circular_coils(N_coils=2, N_fourier=3,
                                      major_radius=0.7, minor_radius=0.4,
                                      key=jax.random.PRNGKey(42))

        # Get initial loss
        init_loss = float(forge_loss_scalar(params, grid_info, eval_cart,
                                             N_segments=16))

        # Optimize
        opt_params, final_loss, aux = optimize_candidate(
            params, grid_info, eval_cart,
            N_segments=16, n_steps=30, learning_rate=5e-3)

        assert final_loss < init_loss, "Optimization did not reduce loss"
        assert jnp.all(jnp.isfinite(opt_params))


class TestPerformance:
    """Performance benchmarks (non-strict — for reporting only)."""

    def test_steps_per_second(self):
        """Benchmark optimization speed on CPU."""
        config = ForgeConfig(
            Nr=12, Ntheta=8, Nz=6,
            N_coils=3, N_fourier=5, N_segments=32,
            N_steps=30, learning_rate=1e-3,
            log_every=30, checkpoint_every=100,
            output_dir=tempfile.mkdtemp(),
        )

        t0 = time.perf_counter()
        results = run_forge(config)
        elapsed = time.perf_counter() - t0

        steps_per_sec = 30 / elapsed
        print(f"\nBenchmark: {elapsed:.1f}s for 30 steps "
              f"({steps_per_sec:.2f} steps/sec)")

        # Very loose bound — just check it actually ran
        assert elapsed < 600, f"Run took over 10 min ({elapsed:.1f}s)"
