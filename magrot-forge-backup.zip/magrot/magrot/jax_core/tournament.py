"""
MagRot Forge — Tournament selection and GPU-ready batch infrastructure.

Implements multi-epoch tournament optimization with Pareto filtering.
CPU mode: sequential candidates.  GPU mode: jax.vmap parallel batch.

The tournament strategy (from MAGROT_Forge_Plan.md Section 10):
  Epoch 1 (Seed):   4,096 candidates at 32^3, 1K steps  -> keep top 25%
  Epoch 2 (Filter): 1,024 candidates at 48^3, 3K steps  -> keep top 25%
  Epoch 3 (Polish): 256 candidates at 64^3, 5K steps     -> select top 10

On CPU (this Space): sequential with small candidate counts for validation.
On GPU (A100 Large): parallel via jax.vmap over the full batch.
"""

import jax
import jax.numpy as jnp
import numpy as np
import optax
import time
from dataclasses import dataclass, field
from typing import Optional

from .grid_jax import make_grid_info
from .biot_savart import init_circular_coils, grid_to_eval_points, fourier_to_all_coils
from .forge_loss import forge_loss, forge_loss_scalar, DEFAULT_WEIGHTS


# ── Candidate initialization ──────────────────────────────────────────

def init_tournament_candidates(n_candidates, config, seed=42):
    """Initialize n_candidates random coil parameter sets.

    Parameters
    ----------
    n_candidates : int
        Number of candidates to create.
    config : dict
        Must contain keys: N_coils, major_radius, minor_radius, N_fourier.
    seed : int

    Returns
    -------
    all_params : jnp.ndarray, shape (n_candidates, N_coils, N_fourier, 3, 2)
    """
    keys = jax.random.split(jax.random.PRNGKey(seed), n_candidates)

    candidates = []
    for k in keys:
        p = init_circular_coils(
            N_coils=config['N_coils'],
            major_radius=config.get('major_radius', 0.7),
            minor_radius=config.get('minor_radius', 0.4),
            N_fourier=config['N_fourier'],
            key=k,
        )
        candidates.append(p)

    return jnp.stack(candidates)


# ── Batch loss evaluation ─────────────────────────────────────────────

def evaluate_batch(all_params, grid_info, eval_cart, weights=None,
                   N_segments=64):
    """Evaluate forge_loss for a batch of candidates.

    On GPU: uses jax.vmap for parallel evaluation.
    On CPU: sequential loop (avoids memory explosion).

    Parameters
    ----------
    all_params : shape (N_candidates, N_coils, N_fourier, 3, 2)
    grid_info : dict
    eval_cart : jnp.ndarray
    weights : dict or None
    N_segments : int

    Returns
    -------
    losses : shape (N_candidates,)
    all_aux : dict of arrays, each shape (N_candidates,)
    """
    if weights is None:
        weights = dict(DEFAULT_WEIGHTS)

    n = all_params.shape[0]

    if jax.default_backend() != 'cpu' and n > 1:
        # GPU: parallel via vmap
        def single_loss(params):
            return forge_loss(params, grid_info, eval_cart, weights, N_segments)

        batched_fn = jax.vmap(single_loss)
        return batched_fn(all_params)
    else:
        # CPU: sequential
        losses = []
        aux_lists = {}
        for i in range(n):
            loss, aux = forge_loss(all_params[i], grid_info, eval_cart,
                                   weights, N_segments)
            losses.append(float(loss))
            for k, v in aux.items():
                aux_lists.setdefault(k, []).append(float(v))

        return (jnp.array(losses),
                {k: jnp.array(v) for k, v in aux_lists.items()})


# ── Tournament selection ──────────────────────────────────────────────

def tournament_select(all_params, losses, all_aux,
                      survival_rate=0.25,
                      pareto_keys=('L_R', 'L_curv')):
    """Select survivors from a tournament epoch.

    Combines loss-based ranking with Pareto optimality to preserve
    diversity in the candidate population.

    Parameters
    ----------
    all_params : shape (N, N_coils, N_fourier, 3, 2)
    losses : shape (N,)
    all_aux : dict with arrays shape (N,)
    survival_rate : float
        Fraction of candidates to keep (0.25 = top 25%).
    pareto_keys : tuple of str
        Two keys from all_aux for 2-objective Pareto filtering.

    Returns
    -------
    survivor_params : shape (N_survivors, ...)
    survivor_indices : list of int
    survivor_losses : shape (N_survivors,)
    """
    N = all_params.shape[0]
    N_keep = max(int(N * survival_rate), 1)

    losses_np = np.asarray(losses)
    sorted_idx = np.argsort(losses_np)

    # Top N_keep by total loss
    top_set = set(sorted_idx[:N_keep].tolist())

    # Pareto-optimal candidates (may add extras beyond N_keep)
    if len(pareto_keys) == 2:
        obj1 = np.asarray(all_aux[pareto_keys[0]])
        obj2 = np.asarray(all_aux[pareto_keys[1]])
        for i in range(N):
            dominated = False
            for j in range(N):
                if i == j:
                    continue
                if (obj1[j] <= obj1[i] and obj2[j] <= obj2[i] and
                        (obj1[j] < obj1[i] or obj2[j] < obj2[i])):
                    dominated = True
                    break
            if not dominated:
                top_set.add(i)

    final_indices = sorted(top_set)
    final_idx_arr = np.array(final_indices)

    return (all_params[final_idx_arr],
            final_indices,
            losses[final_idx_arr])


# ── Single-candidate optimizer ────────────────────────────────────────

def optimize_candidate(coil_params, grid_info, eval_cart,
                       weights=None, N_segments=64,
                       n_steps=500, learning_rate=1e-3):
    """Optimize a single candidate's coil parameters.

    Parameters
    ----------
    coil_params : shape (N_coils, N_fourier, 3, 2)
    grid_info : dict
    eval_cart : jnp.ndarray
    weights : dict or None
    N_segments : int
    n_steps : int
    learning_rate : float

    Returns
    -------
    optimized_params : same shape as coil_params
    final_loss : float
    final_aux : dict
    """
    if weights is None:
        weights = dict(DEFAULT_WEIGHTS)

    schedule = optax.cosine_decay_schedule(
        init_value=learning_rate, decay_steps=n_steps)
    optimizer = optax.adam(learning_rate=schedule)
    opt_state = optimizer.init(coil_params)

    def loss_fn(params):
        return forge_loss_scalar(params, grid_info, eval_cart, weights,
                                 N_segments)

    loss_and_grad = jax.jit(jax.value_and_grad(loss_fn))

    for step in range(n_steps):
        loss_val, grads = loss_and_grad(coil_params)
        updates, opt_state = optimizer.update(grads, opt_state, coil_params)
        coil_params = optax.apply_updates(coil_params, updates)

    _, final_aux = forge_loss(coil_params, grid_info, eval_cart, weights,
                              N_segments)

    return coil_params, float(final_aux['loss']), final_aux


# ── Tournament epoch runner ───────────────────────────────────────────

def run_tournament_epoch(all_params, grid_info, eval_cart,
                         weights=None, N_segments=64,
                         n_steps=500, learning_rate=1e-3,
                         label=''):
    """Run one tournament epoch: optimize all candidates for n_steps.

    Parameters
    ----------
    all_params : shape (N_candidates, N_coils, N_fourier, 3, 2)
    grid_info : dict
    eval_cart : jnp.ndarray
    weights : dict or None
    N_segments : int
    n_steps : int
    learning_rate : float
    label : str
        Epoch label for progress display.

    Returns
    -------
    optimized_params : shape (N_candidates, ...)
    losses : shape (N_candidates,)
    all_aux : dict
    """
    N = all_params.shape[0]
    if weights is None:
        weights = dict(DEFAULT_WEIGHTS)

    print(f"\n{'='*60}")
    print(f"  Tournament Epoch: {label}")
    print(f"  Candidates: {N} | Steps: {n_steps} | LR: {learning_rate:.1e}")
    print(f"{'='*60}")

    opt_params = []
    losses = []
    aux_lists = {}
    t_start = time.perf_counter()

    for i in range(N):
        t0 = time.perf_counter()
        params, loss, aux = optimize_candidate(
            all_params[i], grid_info, eval_cart,
            weights=weights, N_segments=N_segments,
            n_steps=n_steps, learning_rate=learning_rate,
        )
        dt = time.perf_counter() - t0

        opt_params.append(params)
        losses.append(loss)
        for k, v in aux.items():
            aux_lists.setdefault(k, []).append(float(v))

        print(f"  [{i+1:3d}/{N}] loss={loss:12.2f} | "
              f"R_mean={float(aux['R_mean']):8.4f} | "
              f"L_curv={float(aux['L_curv']):6.2f} | "
              f"{dt:.1f}s")

    t_total = time.perf_counter() - t_start
    print(f"\nEpoch complete: {t_total:.1f}s total, "
          f"{t_total/N:.1f}s/candidate")

    return (jnp.stack(opt_params),
            jnp.array(losses),
            {k: jnp.array(v) for k, v in aux_lists.items()})


# ── Full tournament pipeline ──────────────────────────────────────────

@dataclass
class TournamentConfig:
    """Configuration for a multi-epoch tournament."""
    # Coil geometry
    N_coils: int = 3
    N_fourier: int = 5
    major_radius: float = 0.7
    minor_radius: float = 0.4

    # Per-epoch settings: (Nr, Ntheta, Nz, N_segments, n_steps, lr, n_candidates)
    epochs: list = field(default_factory=lambda: [
        # Epoch 1: Seed (coarse, many candidates)
        {'Nr': 12, 'Ntheta': 8, 'Nz': 6, 'N_segments': 32,
         'n_steps': 200, 'lr': 3e-3, 'n_candidates': 8},
        # Epoch 2: Filter (medium, survivors)
        {'Nr': 16, 'Ntheta': 12, 'Nz': 8, 'N_segments': 48,
         'n_steps': 500, 'lr': 1e-3},
        # Epoch 3: Polish (fine, elite)
        {'Nr': 20, 'Ntheta': 16, 'Nz': 10, 'N_segments': 64,
         'n_steps': 1000, 'lr': 5e-4},
    ])

    survival_rate: float = 0.5  # Keep top 50% per epoch (conservative on CPU)
    weights: dict = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    seed: int = 42


def run_tournament(config=None):
    """Run a full multi-epoch tournament.

    Parameters
    ----------
    config : TournamentConfig or None
        If None, uses CPU-friendly defaults.

    Returns
    -------
    results : dict
        Final elite candidates, all epoch histories.
    """
    if config is None:
        config = TournamentConfig()

    coil_config = {
        'N_coils': config.N_coils,
        'N_fourier': config.N_fourier,
        'major_radius': config.major_radius,
        'minor_radius': config.minor_radius,
    }

    # Initialize from first epoch's candidate count
    n_init = config.epochs[0].get('n_candidates', 8)
    all_params = init_tournament_candidates(n_init, coil_config, config.seed)

    epoch_results = []

    for epoch_idx, epoch_cfg in enumerate(config.epochs):
        # Build grid for this epoch
        grid_info = make_grid_info(
            Nr=epoch_cfg['Nr'],
            Ntheta=epoch_cfg['Ntheta'],
            Nz=epoch_cfg['Nz'],
            r_range=(0.2, 1.5),
            z_range=(-0.5, 0.5),
        )
        eval_cart = grid_to_eval_points(grid_info)

        # Optimize all candidates
        opt_params, losses, aux = run_tournament_epoch(
            all_params, grid_info, eval_cart,
            weights=config.weights,
            N_segments=epoch_cfg['N_segments'],
            n_steps=epoch_cfg['n_steps'],
            learning_rate=epoch_cfg['lr'],
            label=f"Epoch {epoch_idx + 1}/{len(config.epochs)}",
        )

        epoch_results.append({
            'params': opt_params,
            'losses': losses,
            'aux': aux,
            'config': epoch_cfg,
        })

        # Select survivors (except for last epoch)
        if epoch_idx < len(config.epochs) - 1:
            survivors, indices, surv_losses = tournament_select(
                opt_params, losses, aux,
                survival_rate=config.survival_rate,
            )
            print(f"\n  Selection: {opt_params.shape[0]} -> {survivors.shape[0]} "
                  f"survivors (best loss: {float(jnp.min(surv_losses)):.2f})")
            all_params = survivors

    # Final ranking
    final_losses = epoch_results[-1]['losses']
    final_params = epoch_results[-1]['params']
    ranking = jnp.argsort(final_losses)

    print(f"\n{'='*60}")
    print(f"  TOURNAMENT COMPLETE")
    print(f"{'='*60}")
    print(f"  Best loss:   {float(final_losses[ranking[0]]):.4f}")
    print(f"  Best R_mean: {float(epoch_results[-1]['aux']['R_mean'][ranking[0]]):.4f}")

    return {
        'final_params': final_params[ranking],
        'final_losses': final_losses[ranking],
        'epoch_results': epoch_results,
        'ranking': ranking,
        'config': config,
    }


# ── GPU memory optimization wrappers ──────────────────────────────────

def checkpoint_forge_loss(coil_params, grid_info, eval_cart, weights,
                          N_segments):
    """Forge loss with jax.checkpoint for GPU memory efficiency.

    Wraps forge_loss_scalar with gradient rematerialization.
    On CPU: jax.checkpoint still works but provides no memory benefit.
    On GPU: reduces per-candidate memory from ~37MB to ~8MB.
    """
    @jax.checkpoint
    def _checkpointed(params):
        return forge_loss_scalar(params, grid_info, eval_cart, weights,
                                 N_segments)
    return _checkpointed(coil_params)


# ── Export utilities ──────────────────────────────────────────────────

def export_coils_csv(coil_params, N_segments=256, output_dir='.'):
    """Export coil curves as CSV files (one per coil)."""
    import os
    os.makedirs(output_dir, exist_ok=True)
    coil_pts = np.asarray(fourier_to_all_coils(coil_params, N_segments))
    paths = []
    for i in range(coil_pts.shape[0]):
        path = os.path.join(output_dir, f'coil_{i}_xyz.csv')
        np.savetxt(path, coil_pts[i], delimiter=',',
                   header='x,y,z', comments='')
        paths.append(path)
    return paths


def export_coils_vtk(coil_params, N_segments=256, filename='coils.vtk'):
    """Export coil curves as VTK polydata (requires pyvista).

    Falls back to CSV if pyvista is not installed.
    """
    coil_pts = np.asarray(fourier_to_all_coils(coil_params, N_segments))
    try:
        import pyvista as pv
        blocks = pv.MultiBlock()
        for i in range(coil_pts.shape[0]):
            pts = coil_pts[i]
            pts_closed = np.concatenate([pts, pts[:1]], axis=0)
            spline = pv.Spline(pts_closed, n_points=N_segments)
            blocks.append(spline, f'coil_{i}')
        blocks.save(filename)
        print(f'Saved VTK: {filename}')
    except ImportError:
        print('PyVista not available. Falling back to CSV export.')
        export_coils_csv(coil_params, N_segments)
